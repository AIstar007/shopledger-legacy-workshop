# ShopLedger invoice fix · Codex evidence pack

A ₹640 rice order with SAVE10 was billed at ₹604.80. Its printed invoice showed ₹679.68. The fix routes invoice lines, discounts, GST, and totals through the same pricing function as checkout.

| Running app observation | Checkout | Original invoice | Fixed invoice |
| --- | ---: | ---: | ---: |
| Discount | ₹64.00 | ₹75.52 | ₹64.00 |
| GST | ₹28.80 | ₹115.20 | ₹28.80 |
| Total | ₹604.80 | ₹679.68 | ₹604.80 |

## Evidence by checkpoint

1. **Architecture and working rules.** AGENTS.md describes the stack and module responsibilities. docs/architecture.png maps the request flow.
2. **Characterization.** Before the fix, seven in-memory tests passed. Six captured existing discrepancies in odd-paisa splitting, mixed HSN slabs, percentage coupon GST, the discount cap, flat discounts, and per-line rounding. The seventh covered a matching explicit GST rate. The original run was observed during the workshop. The included test file is the final revision.
3. **Failing regression.** before-test.txt is a fresh replay of the discounted-rice test against baseline 68c85a9 in an isolated directory. It records the assertion failure and both sets of amounts.
4. **Fix and verification.** invoice.patch contains the production change. after-tests.txt records the full eight-test run on eb2593c. To repeat it, check out that commit and run `node --test` from the repository root. The tests use synthetic orders in memory. The earlier live check used a temporary project copy and reported zero reconciliation mismatches across ten orders. shopledger-invoice-1010.jpg shows the corrected invoice in that copy.
5. **Delivery.** pull-request.json records the PR body, branch, commit, base, and current GitHub state. PR #1 was opened into main and subsequently merged. Its requested “Fixes #1” text refers to the PR itself. [GitHub PR #1](https://github.com/AIstar007/shopledger-legacy-workshop/pull/1)

## Verification scope

The repository database and the baseline Git version had the same SHA-256 when this pack was built: `5eb8a81a552ca87e4d0a1a5c78ae0312af93e45cb70f490470a761460c141b09`.

Automated Codex review was attempted during the workshop and stopped with HTTP 401. Manual review identified a remaining limitation: invoices use current pricing configuration, so later rule changes could affect historical reprints.
